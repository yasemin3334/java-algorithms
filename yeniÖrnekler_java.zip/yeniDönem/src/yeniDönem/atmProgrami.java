package yeniDönem;

import java.util.Scanner;

public class atmProgrami {

	public static void main(String[] args) {
		/*
		 Özellikler

   Programda:

   1️= Bakiye görüntüle
   2️= Para yatır
   3️= Para çek
   4️= Çıkış

   olacak.
		 */
		Scanner scanner=new Scanner(System.in);
		double  bakiye=10000 ,yatir,cek;
		int secim;
		while(true) {
			System.out.println("1-bakiye görüntüleme");
			System.out.println("2-para yatır ");
			System.out.println("3-para çek");
			System.out.println("4-çıkış yap");
			System.out.println("hangi işlemi yapmak istersin:" );
			secim=scanner.nextInt();
			if(secim==1) {
				System.out.println("bakiyeniz:" +bakiye);
				
			}else if(secim==2) {
				System.out.println("ne kadar para yatırmak isterdiniz:");
				yatir=scanner.nextDouble();
				bakiye=bakiye+yatir;
				System.out.println("yeni bakiyeniz:" +bakiye );
				
			}else if(secim==3) {
				System.out.println("ne kadar para çekmek istersin:");
				cek=scanner.nextDouble();
				if(bakiye>cek) {
					bakiye=bakiye-cek;
					System.out.println("yeni bakiyeniz:" +bakiye);
				}else if (bakiye<cek){
					System.out.println("hesapta o kadar paranız yok çekim yapamazsınız :(");
				}
			}else if(secim==4) {
				System.out.println("çıkışınız yapılıyor...");
				break;
			}else {
				System.out.println("hatali işlem");
			}
		}
			
		
		scanner.close();
		
		
	}
	

}
