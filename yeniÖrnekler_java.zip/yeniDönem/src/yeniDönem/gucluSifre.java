package yeniDönem;

import java.nio.charset.CharacterCodingException;
import java.util.Scanner;

public class gucluSifre {

	public static void main(String[] args) {
	/*
	 * 	Kullanıcı bir şifre girecek ve program şifrenin güçlü olup olmadığını kontrol edecek.
		Kontroller:
		✔ En az 8 karakter
		✔ En az 1 büyük harf
		✔ En az 1 sayı 
		*/
		Scanner scanner =new Scanner(System.in);
		System.out.println("lütfen bir şifre girin.");
		while(true) {
		String sifre=scanner.nextLine();
		boolean buyukHarf=false;
		boolean rakam=false;
	
		if(sifre.length()<8) {
			System.out.println("şifre minimum 8 karakterli olmali.");
			continue ;
			
		}
		for(int i=0;i<sifre.length();i++) {
			char harf=sifre.charAt(i);
			if(Character.isUpperCase(harf)) {
				buyukHarf=true;
				
			}
			if(Character.isDigit(harf)) {
				rakam=true;
			}
			
		}
		if(buyukHarf && rakam) {
			System.out.println("şifreniz güçlü. ");
			break;
			
		}else {
			System.out.println("şifre güçsüz tekrar dene");
		}
		
		

	}
	scanner.close();
	}
}
