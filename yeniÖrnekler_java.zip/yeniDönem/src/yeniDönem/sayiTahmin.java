package yeniDönem;

import java.util.Random;
import java.util.Scanner;

public class sayiTahmin {

	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		/*Bilgisayar sayı tutsun

          Kullanıcı tahmin girsin

          Program desin ki:

          “Daha büyük söyle”

          “Daha küçük söyle”

           Doğruysa:

          “Tebrikler, X denemede bildin”  */
		
		Random rnd= new Random();
		int tutulanSayi = rnd.nextInt(100) + 1;
        int tahmin = 0;
        int deneme = 0;
        System.out.println("lütfen bir sayi tahmin et:");
        while(tutulanSayi!=tahmin) {
        	System.out.println("tahminin:");
        	tahmin=scanner.nextInt();
        	deneme++;
        	if(tahmin<tutulanSayi) {
            	System.out.println("tahmin ettiğin değer küçük kaldı biraz daha büyük bir sayi söyle");
            }else if(tahmin>tutulanSayi){
            	System.out.println("tahmin ettiğin değer büyük kaldı biraz daha küçük bir sayi söyle");
            }else {
            	System.out.println("tebrikler"+ deneme+". denemede buldunuz..");
            	
            }
        }
        

	   scanner.close();
		

	}

}
