package yeniDönem;

import java.util.Scanner;

public class notTakipSistem {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println(" Kaç öğrenci gireceksin?");
		int ogrenciSayisi=scanner.nextInt();
		String[] ogrenciAd = new String[ogrenciSayisi];
		double[] ogrenciNotOrt =new double[ogrenciSayisi];
		String eniyiOgrenci="";
		double toplam=0;
		double enYuksek=0;
		for(int i=0;i<ogrenciSayisi;i++) {
			System.out.println((i+1)+". ögrenciyi gir");
			System.out.println("isim:");
			ogrenciAd[i]=scanner.next();
			System.out.println("vize:");
			double vize=scanner.nextDouble();
			System.out.println("final:");
			double final1=scanner.nextDouble();
		    double ort=vize*(0.4)+final1*(0.6);
		    ogrenciNotOrt[i]= ort;
		    toplam += ort;
		    String harf;

            if (ort >= 90) harf = "AA";
            else if (ort >= 80) harf = "BA";
            else if (ort >= 70) harf = "BB";
            else if (ort >= 60) harf = "CB";
            else if (ort >= 50) harf = "CC";
            else harf = "FF";
            System.out.println("Ortalama: " + ort);
            System.out.println("Harf Notu: " + harf);
            if (ort >= 50)
                System.out.println("Durum: Geçti ");
            else
                System.out.println("Durum: Kaldı ");
            if (ort > enYuksek) {
                enYuksek = ort;
                eniyiOgrenci = ogrenciAd[i];
            }
			
		}
			double sınıfOrt=toplam/ogrenciSayisi;
			System.out.println("\n===== SINIF ÖZETİ =====");
	        System.out.println("Sınıf Ortalaması: " + ogrenciNotOrt );
	        System.out.println("En Başarılı Öğrenci: " + eniyiOgrenci + " (" + enYuksek + ")");

	       scanner.close();
		

	}

}
