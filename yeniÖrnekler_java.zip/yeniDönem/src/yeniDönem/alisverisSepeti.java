package yeniDönem;

import java.util.Scanner;

public class alisverisSepeti {

	public static void main(String[] args) {
		/*
		 * Kullanıcı ürün seçer ve toplam fiyat hesaplanır.

         Ürünler:

         Ürün	Fiyat
         Elma	5
         Ekmek	10
         Süt	15
		 */
		Scanner scanner =new Scanner(System.in);
		int secim;
		int toplam=0;
		while(true) {
			System.out.println("lütffen birini secin.");
			System.out.println("1-elma seçtiniz ve fiyatı 5 tl ");
			System.out.println("2-ekmek seçtiniz ve fiyatı 10 tl");
			System.out.println("3-süt seçtiniz ve fiyatı 15 tl");
			System.out.println("4-çıkışı seçtiniz ve çıkış yapılıyor.");
			System.out.println("secim:");
			secim=scanner.nextInt();
			if(secim==1) {
				toplam+=5;
				
			}else if(secim==2) {
				toplam+=10;
			}else if(secim==3) {
				toplam+=15;
				
			}else if(secim==4) {
				break;
			}else {
				System.out.println("geçersiz işlem.");
			}
			
		}
		
		System.out.println("toplam ödeme :"+toplam);
		scanner.close();

	}

}
