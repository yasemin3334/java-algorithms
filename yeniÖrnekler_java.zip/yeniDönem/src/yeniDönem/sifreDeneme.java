package yeniDönem;

import java.util.Scanner;

public class sifreDeneme {

	public static void main(String[] args) {
		/*
		 Kullanıcı:

         kullanıcı adı

         şifre

         girecek.

         Program:

         ✔ doğruysa giriş yapacak
         ✔ yanlışsa tekrar isteyecek
         ✔ 3 yanlış denemede hesap kilitlenecek
		*/
		Scanner scanner =new Scanner(System.in);
		String dogruKullaniciAdi="admin";
		String dogruSifre="12345";
		int hak=3;
		while(hak>0) {
			System.out.println("lütfen bir kullanıcı adi girin:");
			String kullaniciAdi=scanner.nextLine();
			System.out.println("lüttfen bir şifre girin.");
			String sifre=scanner.nextLine();
			if(kullaniciAdi.equals(dogruKullaniciAdi)&&sifre.equals(dogruSifre)) {
				System.out.println("doğru şifre girdiniz");
				break;
			}else  {
				hak--;
				System.out.println("yanlış girdiniz hak:"+hak);
			}
			if(hak==0) {
				System.out.println("hakkınız dolmuştur.");
			}
			
		}
		
		
		scanner.close();
		
	}

}
