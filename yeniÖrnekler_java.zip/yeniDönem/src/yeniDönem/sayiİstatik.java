package yeniDönem;

import java.util.Scanner;

public class sayiİstatik {

	public static void main(String[] args) {
		/*
		 * Amaç

          Kullanıcı:

          birkaç sayı girer

          program şunları hesaplar:

          ✔️ En büyük sayı
          ✔️ En küçük sayı
          ✔️ Ortalama
		 */
		Scanner scanner =new Scanner(System.in);
		System.out.println("kaç sayi girmek isterdin");
		int n =scanner.nextInt();
		int enBüyük ,enKucuk,ort;
		int toplam=0;
		int[] sayilar=new int[n];
		enBüyük=Integer.MIN_VALUE;
		enKucuk=Integer.MAX_VALUE;
		for(int i = 0; i < n; i++) {
			System.out.println((i+1)+". sayiyi girin:");
			sayilar[i]=scanner.nextInt();
			toplam+=sayilar[i];
			if(sayilar[i]>enBüyük) 
				enBüyük= sayilar[i];
			
			if(sayilar[i]<enKucuk) 
				enKucuk=sayilar[i];
				
			
		}
		ort=toplam/n;
		System.out.println("toplam sonuç");
		System.out.println("en  büyük sayi"+enBüyük);
		System.out.println("en küçük sayi "+enKucuk);
		System.out.println("ortalama:"+ort);
		scanner.close();
		
		
		

	}

}
